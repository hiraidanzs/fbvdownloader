# FB Downloader by Ridho Dzaky
Siap upload ke GitHub. Deploy lewat Railway:
1. Tambah repo di GitHub
2. Upload semua file ini
3. Railway → New Project → Deploy from GitHub
